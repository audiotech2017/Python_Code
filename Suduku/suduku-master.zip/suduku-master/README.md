# suduku
Using python

# python
- **python2.7**
- **numpy**
