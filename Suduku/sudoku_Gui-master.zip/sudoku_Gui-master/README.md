# sudoku_Gui
Using python

# python
- **python2.7**
- **numpy**
- **pyqt4**
